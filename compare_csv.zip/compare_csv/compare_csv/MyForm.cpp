
#ifndef MYFORMCPP
#define MYFORMCPP

#include "MyForm.h"
#include "E:\Arbete Monica\VisualStudio\KlasserHA\Header.h"
#include <string>
#include <fstream>
#include <iostream>
#include <msclr\marshal_cppstd.h>

#using <mscorlib.dll>

using namespace System::Data;
using namespace System::ComponentModel;
using namespace System;
using namespace std;

#define MAXCOLS 20000

void comparecsv::MyForm::InitializeComponent(void)
{
	this->button1 = (gcnew System::Windows::Forms::Button());
	this->button2 = (gcnew System::Windows::Forms::Button());
	this->txbExcelfil1 = (gcnew System::Windows::Forms::TextBox());
	this->txbExcelfil2 = (gcnew System::Windows::Forms::TextBox());
	this->label1 = (gcnew System::Windows::Forms::Label());
	this->button3 = (gcnew System::Windows::Forms::Button());
	this->nmrkolumn1 = (gcnew System::Windows::Forms::NumericUpDown());
	this->label2 = (gcnew System::Windows::Forms::Label());
	this->nmrkolumn2 = (gcnew System::Windows::Forms::NumericUpDown());
	(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->nmrkolumn1))->BeginInit();
	(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->nmrkolumn2))->BeginInit();
	this->SuspendLayout();
	// 
	// button1
	// 
	this->button1->Location = System::Drawing::Point(44, 45);
	this->button1->Name = L"button1";
	this->button1->Size = System::Drawing::Size(75, 23);
	this->button1->TabIndex = 0;
	this->button1->Text = L"CSV fil 1";
	this->button1->UseVisualStyleBackColor = true;
	this->button1->Click += gcnew System::EventHandler(this, &MyForm::CSVfil1);
	// 
	// button2
	// 
	this->button2->Location = System::Drawing::Point(44, 83);
	this->button2->Name = L"button2";
	this->button2->Size = System::Drawing::Size(75, 23);
	this->button2->TabIndex = 1;
	this->button2->Text = L"CSV fil 2";
	this->button2->UseVisualStyleBackColor = true;
	this->button2->Click += gcnew System::EventHandler(this, &MyForm::CSVfil2);
	// 
	// txbExcelfil1
	// 
	this->txbExcelfil1->Location = System::Drawing::Point(169, 48);
	this->txbExcelfil1->Name = L"txbExcelfil1";
	this->txbExcelfil1->Size = System::Drawing::Size(319, 20);
	this->txbExcelfil1->TabIndex = 2;
	this->txbExcelfil1->Text = L"C:\\Users\\Monica Hinderup\\Desktop\\Ny mapp (2)\\Resultat fr�n TPYfil.csv";
	this->txbExcelfil1->TextChanged += gcnew System::EventHandler(this, &MyForm::txbExcelfil1_TextChanged);
	// 
	// txbExcelfil2
	// 
	this->txbExcelfil2->Location = System::Drawing::Point(169, 86);
	this->txbExcelfil2->Name = L"txbExcelfil2";
	this->txbExcelfil2->Size = System::Drawing::Size(319, 20);
	this->txbExcelfil2->TabIndex = 3;
	this->txbExcelfil2->Text = L"C:\\Users\\Monica Hinderup\\Desktop\\Ny mapp (2)\\variable.csv\r\n\r\n\r\n";
	// 
	// label1
	// 
	this->label1->AutoSize = true;
	this->label1->Location = System::Drawing::Point(62, 134);
	this->label1->Name = L"label1";
	this->label1->Size = System::Drawing::Size(51, 13);
	this->label1->TabIndex = 4;
	this->label1->Text = L"Kolumn 1";
	// 
	// button3
	// 
	this->button3->Location = System::Drawing::Point(44, 205);
	this->button3->Name = L"button3";
	this->button3->Size = System::Drawing::Size(75, 23);
	this->button3->TabIndex = 5;
	this->button3->Text = L"J�mf�r CSV";
	this->button3->UseVisualStyleBackColor = true;
	this->button3->Click += gcnew System::EventHandler(this, &MyForm::J�mf�rCSV);
	// 
	// nmrkolumn1
	// 
	this->nmrkolumn1->Location = System::Drawing::Point(169, 134);
	this->nmrkolumn1->Name = L"nmrkolumn1";
	this->nmrkolumn1->Size = System::Drawing::Size(39, 20);
	this->nmrkolumn1->TabIndex = 7;
	this->nmrkolumn1->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
	this->nmrkolumn1->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericUpDown1_ValueChanged);
	// 
	// label2
	// 
	this->label2->AutoSize = true;
	this->label2->Location = System::Drawing::Point(62, 170);
	this->label2->Name = L"label2";
	this->label2->Size = System::Drawing::Size(51, 13);
	this->label2->TabIndex = 8;
	this->label2->Text = L"Kolumn 2";
	// 
	// nmrkolumn2
	// 
	this->nmrkolumn2->Location = System::Drawing::Point(169, 170);
	this->nmrkolumn2->Name = L"nmrkolumn2";
	this->nmrkolumn2->Size = System::Drawing::Size(39, 20);
	this->nmrkolumn2->TabIndex = 9;
	this->nmrkolumn2->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
	// 
	// MyForm
	// 
	this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
	this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
	this->ClientSize = System::Drawing::Size(616, 273);
	this->Controls->Add(this->nmrkolumn2);
	this->Controls->Add(this->label2);
	this->Controls->Add(this->nmrkolumn1);
	this->Controls->Add(this->button3);
	this->Controls->Add(this->label1);
	this->Controls->Add(this->txbExcelfil2);
	this->Controls->Add(this->txbExcelfil1);
	this->Controls->Add(this->button2);
	this->Controls->Add(this->button1);
	this->Name = L"MyForm";
	this->Text = L"J�mf�r CSV-filer";
	this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
	(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->nmrkolumn1))->EndInit();
	(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->nmrkolumn2))->EndInit();
	this->ResumeLayout(false);
	this->PerformLayout();

}

System::Void comparecsv::MyForm::CSVfil1(System::Object^ sender, System::EventArgs^ e)
{
	System::Windows::Forms::OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
	openFileDialog1->InitialDirectory = "c:\\";
	openFileDialog1->Filter = "csv files(*.csv) | *.csv | All files(*.*) | *.*";
	openFileDialog1->FilterIndex = 2;
	openFileDialog1->RestoreDirectory = true;

	if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)
	{
		txbExcelfil1->Text = openFileDialog1->FileName;

	}
}

System::Void comparecsv::MyForm::CSVfil2(System::Object^ sender, System::EventArgs^ e)
{
	System::Windows::Forms::OpenFileDialog^ openFileDialog2 = gcnew OpenFileDialog;
	openFileDialog2->InitialDirectory = "c:\\";
	openFileDialog2->Filter = "csv files(*.csv) | *.csv | All files(*.*) | *.*";
	openFileDialog2->FilterIndex = 2;
	openFileDialog2->RestoreDirectory = true;

	if (openFileDialog2->ShowDialog() == System::Windows::Forms::DialogResult::OK)
	{
		txbExcelfil2->Text = openFileDialog2->FileName;

	}
}

System::Void comparecsv::MyForm::J�mf�rCSV(System::Object^ sender, System::EventArgs^ e)
{
	//create normal variables (change from System::string & int to std::string & int
	msclr::interop::marshal_context context;
	string CSVfil1namn = context.marshal_as<string>(txbExcelfil1->Text);
	string CSVfil2namn = context.marshal_as<string>(txbExcelfil2->Text);
	int kolu = (int)nmrkolumn1->Value;
	int kol = (int)nmrkolumn2->Value;

	//Open the files
	ifstream inFile;
	ifstream inFile2;
	inFile.open(CSVfil1namn);
	if (inFile.is_open()) {
		inFile2.open(CSVfil2namn);
		if (inFile2.is_open()) {
			//create two datatables with stuff from the file
			DatabaseClass* table1 = new DatabaseClass();
			DatabaseClass* table2 = new DatabaseClass();

			cli::array<String^>^ testarray1 = table1->CreateAndPopulateTable(inFile, ";");
			cli::array<String^>^ testarray2 = table2->CreateAndPopulateTable(inFile2, ";");

			//Compare & create a new column with the result
			msclr::interop::marshal_context context1;
			msclr::interop::marshal_context contex2;
			string str1 = context1.marshal_as<string>(testarray1[kolu-1]);
			string str2 = contex2.marshal_as<string>(testarray2[kol-1]);
			char* strarr1 = &str1[0];
			char* strarr2 = &str2[0];
			char* values1[MAXCOLS];
			char* values2[MAXCOLS];

			int len1 = table1->DatabaseClass::GetValuesForColumn(strarr1, values1, MAXCOLS);
			int len2 = table2->DatabaseClass::GetValuesForColumn(strarr2, values2, MAXCOLS);

			cli::array<String^>^ csvnamn1= txbExcelfil1->Text->Split('.');
			cli::array<String^>^ csvnamn2 = txbExcelfil2->Text->Split('.');
			string csvnamnstr1 = context.marshal_as<string>(csvnamn1[0]);
			string csvnamnstr2 = context.marshal_as<string>(csvnamn2[0]);

			table1->tocsv(str2, values1, table2, csvnamnstr1, testarray1);

			for (int i = 0; i < len1; i++) {
				GlobalFree(values1[i]);
			}
			

			table2->tocsv(str1, values2, table1, csvnamnstr2, testarray2);
			
			for (int k = 0; k < len2; k++) {
				GlobalFree(values2[k]);
			}
			delete[] testarray1;
			delete[] testarray2;
			delete table1;
			delete table2;
		}
		inFile2.close();
	}
	//else do nothing
	
	inFile.close();
	system("pause");
} 

#endif //MYFORMCPP