#include "MyForm.h"

using namespace System;
using namespace System::Windows::Forms;
using namespace System::IO;

[STAThreadAttribute]

int main()
{
	Application::SetCompatibleTextRenderingDefault(false);
	Application::EnableVisualStyles();
	comparecsv::MyForm frm;
	Application::Run(% frm);
	return 0;
}