#pragma once
#ifndef MYFORMHPP
#define MYFORMHPP

namespace comparecsv {

	using namespace std;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;
	protected:
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::TextBox^ txbExcelfil1;
	private: System::Windows::Forms::TextBox^ txbExcelfil2;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::NumericUpDown^ nmrkolumn1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::NumericUpDown^ nmrkolumn2;
	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void);
#pragma endregion
	private: System::Void CSVfil1(System::Object^ sender, System::EventArgs^ e);
	private: System::Void CSVfil2(System::Object^ sender, System::EventArgs^ e);
	private: System::Void J�mf�rCSV(System::Object^ sender, System::EventArgs^ e);
	private: System::Void numericUpDown1_ValueChanged(System::Object^ sender, System::EventArgs^ e) {   }
	private: System::Void txbExcelfil1_TextChanged(System::Object^ sender, System::EventArgs^ e) {}
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	};
}
#endif //MYFORMHPP